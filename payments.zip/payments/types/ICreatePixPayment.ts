export interface ICreatePixPayment {
  payer: {
    email: string,
    first_name: string,
    last_name: string,
    identification: {
      number: string,
    }
  },
  description: string,
  transaction_amount: number,
}

export interface ICreatePixPaymentRequest extends ICreatePixPayment {
  client_id: string;
  service_id?: string;
  product_id?: string;
}

export interface ICreatePixPaymentResponse {
  transaction_data: {
    qr_code_base64: string;
    qr_code: string;
    ticket_url: string;
  }
}