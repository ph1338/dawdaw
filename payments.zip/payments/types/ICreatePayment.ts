// Ajustando a interface ICreatePayment
export interface ICreatePayment {
  client_id: string;
  checkout_id: string;
  payment_method?: string;
  payment_status: string;
  service_id?: string;
  product_id?: string;
  transaction_amount?: number;
}

// Ajustando a interface ICreatePaymentRequest
export interface ICreatePaymentRequest {
  client_id: string;
  payment_method: string;
  receipt_email: string;
  
  service_id?: string;
  product_id?: string;
  payer?: {
    card_token: string;
    cpf: string;
    address: {
      line1: string;
      city: string;
      state: string;
      postal_code: string;
      country: string;
    };
  };
}
