export default interface ICreatePaymentIntentRequest {
  client_id: string;
  payment_method: string;
  receipt_email: string;
  service_id?: string;
  product_id?: string;
  transaction_amount?: number;
  payer?: {
    card_token: string;
    cpf: string;
    address: {
      line1: string;
      city: string;
      state: string;
      postal_code: string;
      country: string;
    };
  };
}


export interface ICreatePaymentIntentBoletoResponse {
  boleto_display_details: {
    expires_at: number,
    hosted_voucher_url: string,
    number: string,
    pdf: string,
  }
}

export interface ICreatePaymentIntentCardResponse {
  status: string;
}