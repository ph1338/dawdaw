import Stripe from 'stripe'

export default interface Listener {
  eventListener(event: Stripe.Event): Promise<void>;
}