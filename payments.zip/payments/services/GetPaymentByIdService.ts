
import { inject, injectable } from 'tsyringe';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import Payment from '../infra/typeorm/entities/Payment';
import AppError from '@shared/errors/AppError';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository';

@injectable()
class GetPaymentByIdService {
  constructor(
    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,
  ) {}

  async execute(user_id: string, payment_id: string): Promise<Payment> {
    const user = await this.usersRepository.findById(user_id);
    if (!user) {
      throw new AppError(
        'Não conseguimos encontrar o seu registro. Faça login e tente novamente.',
      );
    }
    if (user.type_permission !== 'ADMIN') {
      throw new AppError('Acesso Negado');
    }

    const payment = await this.paymentsRepository.getPaymentById(payment_id);
    if (!payment) {
      throw new AppError('Este pagamento não existe.');
    }

    return payment;
  }
}

export default GetPaymentByIdService;
