import { inject, injectable } from 'tsyringe';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import Payment from '../infra/typeorm/entities/Payment';
import AppError from '@shared/errors/AppError';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository';

@injectable()
class GetPaymentsByClientIdService {
  constructor(
    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,
  ) {}

  async execute(user_id: string, client_id: string): Promise<Payment[]> {
    const user = await this.usersRepository.findById(client_id);
    if (!user) {
      throw new AppError(
        'Não conseguimos encontrar o seu registro. Faça login e tente novamente.',
      );
    }
    if (user.type_permission !== 'ADMIN') {
      if (user_id !== client_id) {
        throw new AppError('Acesso Negado');
      }

      const payments = await this.paymentsRepository.getPaymentsByClientId(client_id);
      return payments;
    }

    const payments = await this.paymentsRepository.getPaymentsByClientId(
      client_id,
    );

    return payments;
  }
}

export default GetPaymentsByClientIdService;
