import { inject, injectable } from 'tsyringe';
import IMercadoPagoProvider from '../providers/models/IMercadoPagoProvider';
import {
  ICreatePixPaymentRequest,
  ICreatePixPaymentResponse,
} from '../types/ICreatePixPayment';
import IRequestsRepository from '@modules/orders/repositories/IRequestsRepository';
import IAccountsSmurfsRepository from '@modules/accountsSmurfs/repositories/IAccountsSmurfRepository';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository'
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import AppError from '@shared/errors/AppError';


@injectable()
class CreatePixPaymentService {
  constructor(
    @inject('UsersRepository')
    private usersRepository: IUsersRepository,


    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,

    @inject('MercadoPagoProvider')
    private mercadoPagoProvider: IMercadoPagoProvider,

    @inject('RequestsRepository')
    private requestsRepository: IRequestsRepository,

    @inject('AccountsSmurfsRepository')
    private accountsSmurfsRepository: IAccountsSmurfsRepository,
  ) {}

  async execute({
    client_id,
    service_id,
    product_id,
    transaction_amount,
    payer,
  }: ICreatePixPaymentRequest): Promise<ICreatePixPaymentResponse> {


   let order = undefined;
    if (service_id) {
      order = await this.requestsRepository.findById(service_id);
    }
    if (product_id) {
      order = await this.accountsSmurfsRepository.findById(product_id);
    }
    if (!order) {
      throw new AppError('Não foi possível recuperar o seu pedido. Contate os administradores da plataforma.');
    }
    const generatedPayment = await this.mercadoPagoProvider.createPayment({
      payer,
      description: 'Elomania Servicos Em Jogos Eletronicos',
      transaction_amount: transaction_amount,
    });


    const { id, status } = generatedPayment.body;

    const payment = await this.paymentsRepository.createPayment({
      client_id,
      checkout_id: id,
      payment_method: 'pix',
      payment_status: status,
      service_id,
      product_id,
    });

    if (!payment) {
      throw new AppError(
        'Não foi possivel registrar o pagamento. Contate os administradores da plataforma.',
      );
    }

    const { qr_code_base64, qr_code, ticket_url } =
      generatedPayment.body.point_of_interaction.transaction_data;

    const transaction_data = {
      transaction_data: {
        qr_code_base64,
        qr_code,
        ticket_url,
      },
    };

    return transaction_data;
  }
}

export default CreatePixPaymentService;
