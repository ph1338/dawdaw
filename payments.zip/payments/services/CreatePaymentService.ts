import { inject, injectable } from 'tsyringe';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import { ICreatePaymentRequest } from '../types/ICreatePayment';
import AppError from '@shared/errors/AppError';
import Payment from '../infra/typeorm/entities/Payment';
import IStripeProvider from '@modules/subscriptions/providers/StripeProvider/models/IStripeProvider';
import IRequestsRepository from '@modules/orders/repositories/IRequestsRepository';
import IAccountsSmurfsRepository from '@modules/accountsSmurfs/repositories/IAccountsSmurfRepository';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository'
import ICreatePaymentIntentRequest from '../types/ICreatePaymentIntent';

@injectable()
class CreatePaymentService {
  constructor(
    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,

    @inject('StripeProvider')
    private stripeProvider: IStripeProvider,

    @inject('RequestsRepository')
    private requestsRepository: IRequestsRepository,

    @inject('AccountsSmurfsRepository')
    private accountsSmurfsRepository: IAccountsSmurfsRepository,
  ) {}

  async execute({
    client_id,
    receipt_email,
    payment_method,
    service_id,
    product_id,
    transaction_amount,
    payer,
  }: ICreatePaymentIntentRequest): Promise<any> {
    const stripe = this.stripeProvider.getStripe();
    const user = await this.usersRepository.findById(client_id);
    if (!user) {
      throw new AppError('Você precisa fazer login antes de continuar.');
    }
    
    let order = undefined;
    if (service_id) {
      order = await this.requestsRepository.findById(service_id);
      
    }
    if (product_id) {
      order = await this.accountsSmurfsRepository.findById(product_id);
    }

    if (!order) {
      throw new AppError('Não foi possível recuperar o seu pedido. Contate os administradores da plataforma.');
    }

   let orderId: string = 'ecommerce_id' in order ? order.ecommerce_id : '';

    // let currency;
    // switch (order.server) {
    //   case 'BR': currency = 'brl'; break;
    //   case 'USD': currency = 'usd'; break;
    //   case 'EUR': currency = 'eur'; break;
    //   default: currency = 'usd'; break;
    // }

    let currency = 'brl'
    // if (payment_method === 'boleto') currency = 'brl';

    // if (payment_method === 'boleto') {
    //   const paymentIntentConfig: any = {
    //     amount: Math.round(order.price * 100),
    //     currency,
    //     confirm: true,
    //     receipt_email,
    //     statement_descriptor: `ELOMANIA SERVICOS EM J`,
    //     payment_method_types: ['boleto'],
    //     metadata: { order_id: order.id },
    //     payment_method_options: {
    //       boleto: { expires_after_days: 3 },
    //     },
    //     payment_method_data: {
    //       type: 'boleto',
    //       billing_details: {
    //         name: order.client.name,
    //         email: receipt_email,
    //         address: {
    //           line1: order.client.address || payer?.address.line1,
    //           city: order.client.city || payer?.address.city,
    //           state: order.client.state || payer?.address.state,
    //           postal_code: order.client.cep || payer?.address.postal_code,
    //           country: "BR",
    //         },
    //       },
    //       boleto: { tax_id: payer?.cpf },
    //     },
    //   };

    //   const paymentIntent = await stripe.paymentIntents.create(paymentIntentConfig);
    //   if (!paymentIntent || !paymentIntent.client_secret) {
    //     throw new AppError('Não foi possível criar o PaymentIntent. Tente novamente mais tarde.');
    //   }

    //   const payment = await this.paymentsRepository.createPayment({
    //     client_id,
    //     payment_method,
    //     checkout_id: paymentIntent.id,
    //     payment_status: paymentIntent.status,
    //     service_id,
    //     product_id,
    //   });
      
    //   if (!payment) {
    //     throw new AppError('Não foi possivel registrar o pagamento em nossa base de dados. Contate os administradores da plataforma.');
    //   }

    //   return paymentIntent;

    // } 

      let product_name = 'Elomania Serviços em Jogos Eletrônicos.'
      let product_images = ['https://app-elomania-v2-uploads.s3.amazonaws.com/prata.svg', 'https://app-elomania-v2-uploads.s3.amazonaws.com/mestre_100.svg']
      let product_quantity = 1

      if (!transaction_amount) {
        throw new AppError('transaction_amount não está definido.');
    }

      const session = await stripe.checkout.sessions.create({
        line_items: [
          {
            price_data: {
              currency,
              unit_amount: Math.round(transaction_amount * 100),
              product_data: {
                name: product_name, 
              }
            },
            quantity: product_quantity 
          }
        ],
        mode: 'payment',
        payment_method_types: ['card', 'boleto'],
        metadata: { order_id: orderId },
        customer_email: user.email,
        expires_at: Math.floor((new Date().getTime() + 30 * 60 * 1000) / 1000),
        success_url: 'https://elomania.com/dashboard',
        cancel_url: "https://elomania.com/",
      });
      if (!session || !session.url) {
        throw new AppError('Não foi possível gerar uma sessão para realizar o checkout. Tente novamente mais tarde.');
      }
  
      const payment = await this.paymentsRepository.createPayment({
        client_id,
        checkout_id: session.id,
        payment_status: session.payment_status,
        payment_method: payment_method,
        service_id,
        product_id,
      });

      if (!payment) {
        throw new AppError('Não foi possivel registrar o pagamento em nossa base de dados. Contate os administradores da plataforma.');
      }
  
      return session;
  }
}

export default CreatePaymentService;
