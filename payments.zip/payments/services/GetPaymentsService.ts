import { inject, injectable } from 'tsyringe';
import Payment from '../infra/typeorm/entities/Payment';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository';
import AppError from '@shared/errors/AppError';

@injectable()
class GetPaymentsService {
  constructor(
    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,
  ) {}

  async execute(user_id: string): Promise<Payment[]> {
    const user = await this.usersRepository.findById(user_id);
    if (!user) {
      throw new AppError(
        'Não conseguimos encontrar o seu registro. Faça login e tente novamente.',
      );
    }
    if (user.type_permission !== 'ADMIN') {
      throw new AppError('Acesso Negado');
    }
    const payments = await this.paymentsRepository.getPayments();
    return payments;
  }
}

export default GetPaymentsService;
