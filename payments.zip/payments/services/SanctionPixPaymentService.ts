import { inject, injectable } from 'tsyringe';
import IMercadoPagoProvider from '../providers/models/IMercadoPagoProvider';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import IRequestsRepository from '@modules/orders/repositories/IRequestsRepository';
import IAccountsSmurfsRepository from '@modules/accountsSmurfs/repositories/IAccountsSmurfRepository';
import logger from '@shared/functions/logger';

@injectable()
class SanctionPixPaymentService {
  constructor(
    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,

    @inject('MercadoPagoProvider')
    private mercadoPagoProvider: IMercadoPagoProvider,

    @inject('RequestsRepository')
    private requestsRepository: IRequestsRepository,

    @inject('AccountsSmurfsRepository')
    private accountsSmurfsRepository: IAccountsSmurfsRepository,
  ) {}

  async execute(payment_id: number): Promise<void> {
    const dbPayment = await this.paymentsRepository.getPaymentByCheckoutId(
      payment_id.toString(),
    );
    if (!dbPayment) {
      throw new Error(
        `Não foi possível encontrar o registro do pagamento: ${payment_id}`,
      );
    }

    const mpPayment = await this.mercadoPagoProvider.getPaymentById(payment_id);

    if (dbPayment.service_id) {
      const order = await this.requestsRepository.findById(
        dbPayment.service_id,
      );
      if (!order) {
        logger.warn(
          `[MercadoPago] O pedido ${dbPayment.service_id} não existe. Isso impediu o processamento do evento ${payment_id}`,
        );
        return;
      }

      order.status_payment = mpPayment.body.status;
      this.requestsRepository.save(order);
    }
    if (dbPayment.product_id) {
      const order = await this.accountsSmurfsRepository.findById(
        dbPayment.product_id,
      );
      if (!order) {
        logger.warn(
          `[MercadoPago] O produto ${dbPayment.service_id} não existe. Isso impediu o processamento do evento ${payment_id}`,
        );
        return;
      }

      order.status_payment = mpPayment.body.status;
      this.accountsSmurfsRepository.save(order);
    }

    dbPayment.payment_status = mpPayment.body.status;
    this.paymentsRepository.save(dbPayment);
  }
}

export default SanctionPixPaymentService;
