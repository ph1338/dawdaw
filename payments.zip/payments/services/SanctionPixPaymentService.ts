import { inject, injectable } from 'tsyringe'
import IMercadoPagoProvider from '../providers/models/IMercadoPagoProvider'
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository'


@injectable()
class SanctionPixPaymentService {
  constructor(
    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,

    @inject('MercadoPagoProvider')
    private mercadoPagoProvider: IMercadoPagoProvider,
  ) {}

  async execute(payment_id: number): Promise<void> {
    const dbPayment = await this.paymentsRepository.getPaymentByCheckoutId(payment_id.toString());
    if (!dbPayment) {
      throw new Error(
        `Não foi possível encontrar o registro do pagamento: ${payment_id}`,
      );
    }

    const mpPayment = await this.mercadoPagoProvider.getPaymentById(payment_id);
    
    dbPayment.payment_status = mpPayment.body.status;
    this.paymentsRepository.save(dbPayment);
  }
}

export default SanctionPixPaymentService;