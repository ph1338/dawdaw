import { inject, injectable } from 'tsyringe';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import IStripeProvider from '@modules/subscriptions/providers/StripeProvider/models/IStripeProvider';
import INotificationsRepository from '@modules/notifications/repositories/INotificationsRepository';
import IRequestsRepository from '@modules/orders/repositories/IRequestsRepository';
import IAccountsSmurfsRepository from '@modules/accountsSmurfs/repositories/IAccountsSmurfRepository';
import stripeConfig from '@config/stripe';

import AppError from '@shared/errors/AppError';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository';
import ISubscriptionsRepository from '@modules/subscriptions/infra/typeorm/repositories/models/ISubscriptionsRepository'
import { dispatchEvent } from '../webhooks/EventHandler'

@injectable()
class SanctionPaymentService {
  constructor(
    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,

    @inject('StripeProvider')
    private stripeProvider: IStripeProvider,

    @inject('NotificationsRepository')
    private notificationsRepository: INotificationsRepository,

    @inject('RequestsRepository')
    private requestsRepository: IRequestsRepository,

    @inject('AccountsSmurfsRepository')
    private accountsSmurfsRepository: IAccountsSmurfsRepository,

    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('SubscriptionsRepository')
    private subscriptionsRepository: ISubscriptionsRepository,
  ) {}

  async execute(
    payload: any,
    signature: string | string[] | undefined
  ): Promise<void> {
    const stripe = this.stripeProvider.getStripe();
    
    if (!signature) {
      throw new AppError('Stripe Signature not provided.', 400);
    }

    // const event = stripe.webhooks.constructEvent(
    //   JSON.stringify(payload),
    //   signature,
    //   stripeConfig.webhook,
    // );
    const event = stripe.webhooks.constructEvent(payload, signature, stripeConfig.webhook)
    dispatchEvent(event.type, event);
  }
}

export default SanctionPaymentService;
