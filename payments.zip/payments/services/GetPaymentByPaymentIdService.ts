import { inject, injectable } from 'tsyringe';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import Payment from '../infra/typeorm/entities/Payment';
import AppError from '@shared/errors/AppError';

@injectable()
class GetPaymentByPaymentIdService {
  constructor(
    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,
  ) {}

  async execute(payment_id: string): Promise<Payment> {
    const payment = await this.paymentsRepository.getPaymentByPaymentId(
      payment_id,
    );

    if (!payment) {
      throw new AppError('Este pagamento não existe.');
    }

    return payment;
  }
}

export default GetPaymentByPaymentIdService;
