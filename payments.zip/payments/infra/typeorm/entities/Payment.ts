import {
  Entity,
  Column,
  CreateDateColumn,
  PrimaryColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Expose } from 'class-transformer';
import { User } from '@modules/users/infra/typeorm/entities/users/User';
import { v4 } from 'uuid';

@Entity('payments')
class Payment {
  @PrimaryColumn()
  id: string;

  @Column()
  client_id: string;

  @ManyToOne(() => User, { onDelete: 'SET NULL', onUpdate: 'NO ACTION' })
  @JoinColumn({ name: 'client_id' })
  client: User;

  @Column()
  checkout_id: string;

  @Column()
  payment_status: string;

  @Column()
  payment_method: string;

  @Column({ nullable: true })
  service_id: string;

  @Column({ nullable: true })
  product_id: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  constructor() {
    if (!this.id) {
      this.id = v4();
    }
  }
}

export default Payment;
