import Payment from '../../entities/Payment';
import { ICreatePayment } from '@modules/payments/types/ICreatePayment';

interface IPaymentsRepository {
  createPayment({
    client_id,
    checkout_id,
    payment_status,
    payment_method,
    service_id,
    product_id,
  }: ICreatePayment): Promise<Payment | undefined>;
  deletePayment(id: string): Promise<void>
  getPaymentById(id: string): Promise<Payment | undefined>;
  getPaymentByCheckoutId(checkout_id: string): Promise<Payment | undefined>;
  getPaymentsByClientId(client_id: string): Promise<Payment[]>;
  getPayments(): Promise<Payment[]>;
  save(payment: Payment): Promise<Payment>;
}

export default IPaymentsRepository;
