import { Repository, getRepository } from 'typeorm';
import IPaymentsRepository from '../models/IPaymentsRepository';
import Payment from '../../entities/Payment';
import { ICreatePayment } from '@modules/payments/types/ICreatePayment'

class PaymentsRepository implements IPaymentsRepository {
  private ormRepository: Repository<Payment>;

  constructor() {
    this.ormRepository = getRepository(Payment);
  }

  async createPayment({
    client_id,
    checkout_id,
    payment_status,
    payment_method,
    service_id,
    product_id,
  }: ICreatePayment): Promise<Payment | undefined> {
    const result = await this.ormRepository.create({
      client_id,
      checkout_id,
      payment_status,
      payment_method,
      service_id,
      product_id,
    });

    await this.ormRepository.save(result);
    return result;
  }

  async deletePayment(id: string): Promise<void> {
    this.ormRepository.delete(id);
  }

  async getPaymentById(id: string): Promise<Payment | undefined> {
    const result = await this.ormRepository.findOne({
      where: {
        id,
      },
    });

    return result;
  }

  async getPaymentByCheckoutId(checkout_id: string): Promise<Payment | undefined> {
    const result = await this.ormRepository.findOne({
      where: {
        checkout_id,
      },
    });

    return result;
  }

  async getPaymentsByClientId(client_id: string): Promise<Payment[]> {
    const result = await this.ormRepository.find({
      where: {
        client_id,
      },
    });

    return result;
  }

  async getPayments(): Promise<Payment[]> {
    const result = await this.ormRepository.find();
    return result;
  }

  async save(payment: Payment): Promise<Payment> {
    const result = await this.ormRepository.save(payment);
    if (!result) {
      throw new Error(`Não foi possivel salvar o pagamento: ${payment}`);
    }

    return result;
  }
}

export default PaymentsRepository;
