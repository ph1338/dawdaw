import { Router } from 'express';
import CreatePaymentController from '../controllers/CreatePaymentController';
import CreatePixPaymentController from '../controllers/CreatePixPaymentController';
import GetPaymentByIdController from '../controllers/GetPaymentByIdController';
import GetPaymentByStripeIdController from '../controllers/GetPaymentByPaymentIdController';
import GetPaymentsByClientIdController from '../controllers/GetPaymentsByClientIdController';
import GetPaymentsController from '../controllers/GetPaymentsController';
import SanctionPaymentController from '../controllers/SanctionPaymentController';
import ensureAuthenticated from '@modules/users/infra/http/middlewares/ensureAuthenticated';
import SanctionPixPaymentController from '../controllers/SanctionPixPaymentController';
import { registerEvent } from '@modules/payments/webhooks/EventHandler';
import CheckoutExpireEvent from '@modules/payments/webhooks/CheckoutExpiredEvent'
import CheckoutCompletedEvent from '@modules/payments/webhooks/CheckoutCompletedEvent'
import InvoicePaymentEvent from '@modules/payments/webhooks/InvoicePaymentEvent'
import SubscriptionDeletedEvent from '@modules/payments/webhooks/SubscriptionDeletedEvent'
import GetUserPaymentsController from '../controllers/GetUserPaymentsController'

const createPaymentController = new CreatePaymentController();
const createPixPaymentController = new CreatePixPaymentController();
const getPaymentByIdController = new GetPaymentByIdController();
const getPaymentByStripeIdController = new GetPaymentByStripeIdController();
const getPaymentsByClientIdController = new GetPaymentsByClientIdController();
const getPaymentsController = new GetPaymentsController();
const getUserPaymentsController = new GetUserPaymentsController();
const sanctionPaymentController = new SanctionPaymentController();
const sanctionPixPaymentController = new SanctionPixPaymentController();

registerEvent('checkout.expired', CheckoutExpireEvent);
registerEvent('checkout.session.completed', CheckoutCompletedEvent);
registerEvent('invoice.payment_succeeded', InvoicePaymentEvent);
registerEvent('invoice.payment_failed', InvoicePaymentEvent);
registerEvent('customer.subscription.deleted', SubscriptionDeletedEvent);
registerEvent('payment_intent.payment_failed', InvoicePaymentEvent);
registerEvent('payment_intent.created', InvoicePaymentEvent);
registerEvent('payment_intent.succeeded', InvoicePaymentEvent);

const paymentsRoutes = Router();

paymentsRoutes.post(
  '/create-payment',
  ensureAuthenticated,
  createPaymentController.handle,
);
paymentsRoutes.post(
  '/create-pix-payment',
  ensureAuthenticated,
  createPixPaymentController.handle,
);
paymentsRoutes.get(
  '/', 
  ensureAuthenticated, 
  getPaymentsController.handle
);
paymentsRoutes.get(
  '/u/',
  ensureAuthenticated,
  getUserPaymentsController.handle
);
paymentsRoutes.get(
  '/id/:id',
  ensureAuthenticated,
  getPaymentByIdController.handle,
);
paymentsRoutes.get(
  '/payment-id/:payment_id',
  ensureAuthenticated,
  getPaymentByStripeIdController.handle,
);
paymentsRoutes.get(
  '/client-id/:client_id',
  ensureAuthenticated,
  getPaymentsByClientIdController.handle,
);

paymentsRoutes.post('/sanction-payment', sanctionPaymentController.handle);

paymentsRoutes.post(
  '/sanction-pix-payment',
  sanctionPixPaymentController.handle,
);

export default paymentsRoutes;
