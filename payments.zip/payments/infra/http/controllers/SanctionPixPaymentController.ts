import SanctionPixPaymentService from '@modules/payments/services/SanctionPixPaymentService';
import { Request, Response } from 'express';
import { payment } from 'mercadopago';
import { container } from 'tsyringe';


class SanctionPixPaymentController {
  async handle(request: Request, response: Response): Promise<void> {
    response.status(201).json({});

    const { type, action, data } = request.body;

    if (type === 'payment' || action === 'payment.update') {
        
      const sanctionPixPaymentService = container.resolve(
        SanctionPixPaymentService,
      );
      await sanctionPixPaymentService.execute(data.id);
    }
  }
}

export default SanctionPixPaymentController;
