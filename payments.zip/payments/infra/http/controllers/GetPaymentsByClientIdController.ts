import GetPaymentsByClientIdService from '@modules/payments/services/GetPaymentsByClientIdService';
import { Request, Response } from 'express';
import { container } from 'tsyringe';

class GetPaymentsByClientIdController {
  async handle(request: Request, response: Response): Promise<Response> {
    const { id } = request.user;
    const { client_id } = request.params;

    const getPaymentsByClientId = container.resolve(
      GetPaymentsByClientIdService,
    );

    const payments = await getPaymentsByClientId.execute(id, client_id);

    return response.status(200).json(payments);
  }
}

export default GetPaymentsByClientIdController;
