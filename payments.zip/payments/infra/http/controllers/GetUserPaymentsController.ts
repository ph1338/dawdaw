import GetPaymentsByClientIdService from '@modules/payments/services/GetPaymentsByClientIdService';
import GetUserPaymentsService from '@modules/payments/services/GetUserPaymentsService'
import { Request, Response } from 'express';
import { container } from 'tsyringe';

class GetUserPaymentsController {
  async handle(request: Request, response: Response): Promise<Response> {
    const { id } = request.user;

    const getUserPaymentsService = container.resolve(
      GetUserPaymentsService,
    );

    const payments = await getUserPaymentsService.execute(id);

    return response.status(200).json(payments);
  }
}

export default GetUserPaymentsController;
