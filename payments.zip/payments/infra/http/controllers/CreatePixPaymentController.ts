import CreatePixPaymentService from '@modules/payments/services/CreatePixPaymentService';
import AppError from '@shared/errors/AppError'
import { Request, Response } from 'express';
import { container } from 'tsyringe';

class CreatePixPaymentController {
  async handle(request: Request, response: Response): Promise<Response> {
    const { service_id, product_id, payer, description, transaction_amount } = request.body;

    try {
      const createPixPaymentService = container.resolve(
        CreatePixPaymentService,
      );
      const transaction_data = await createPixPaymentService.execute({
        client_id: request.user.id,
        service_id,
        product_id,
        payer,
        description,
        transaction_amount,
      });

      return response.status(201).json(transaction_data);
    } catch (err) {

      if (err instanceof Error && err.name.includes('MercadoPago')) {
        throw new AppError('Não foi possivel gerar o QR Code para efetuar o pagamento com PIX. Tente novamente.')
      }
      throw err;
    }
  }
}

export default CreatePixPaymentController;
