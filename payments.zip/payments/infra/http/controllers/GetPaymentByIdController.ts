import GetPaymentByIdService from '@modules/payments/services/GetPaymentByIdService';
import { Request, Response } from 'express';
import { container } from 'tsyringe';

class GetPaymentByIdController {
  async handle(request: Request, response: Response): Promise<Response> {
    const { id } = request.params;

    const getPaymentByIdService = container.resolve(GetPaymentByIdService);

    const payment = await getPaymentByIdService.execute(request.user.id, id);

    return response.status(200).json(payment);
  }
}

export default GetPaymentByIdController;
