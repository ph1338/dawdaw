import GetPaymentsService from '@modules/payments/services/GetPaymentsService';
import { Request, Response } from 'express';
import { container } from 'tsyringe';

class GetPaymentsController {
  async handle(request: Request, response: Response): Promise<Response> {
    const getPaymentsService = container.resolve(GetPaymentsService);

    const payments = await getPaymentsService.execute(request.user.id);

    return response.status(200).json(payments);
  }
}

export default GetPaymentsController;
