import GetPaymentByPaymentIdService from '@modules/payments/services/GetPaymentByPaymentIdService';
import { Request, Response } from 'express';
import { container } from 'tsyringe';

class GetPaymentByStripeIdController {
  async handle(request: Request, response: Response): Promise<Response> {
    const { payment_id } = request.params;

    const getPaymentByPaymentIdService = container.resolve(
      GetPaymentByPaymentIdService,
    );

    const payment = await getPaymentByPaymentIdService.execute(payment_id);

    return response.status(200).json(payment);
  }
}

export default GetPaymentByStripeIdController;
