import SanctionPaymentService from '@modules/payments/services/SanctionPaymentService';
import { Request, Response } from 'express';
import { container } from 'tsyringe';

class SanctionPaymentController {
  async handle(request: Request, response: Response): Promise<void> {
    const payload = request.body;
    const signature = request.headers['stripe-signature'];

    try {
      const sanctionPaymentService = container.resolve(SanctionPaymentService);
      sanctionPaymentService.execute(payload, signature);
    } catch (err) {
      console.error('Stripe Webhook Error: ' + err);
      response.status(400).send();
    } finally {
      response.status(200).send();
    }
  }
}

export default SanctionPaymentController;
