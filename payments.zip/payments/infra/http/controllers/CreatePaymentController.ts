import CreatePaymentService from '@modules/payments/services/CreatePaymentService';
import AppError from '@shared/errors/AppError'
import logger from '@shared/functions/logger'
import { Request, Response } from 'express';
import Stripe from 'stripe'
import { container } from 'tsyringe';

class CreatePaymentController {
  async handle(request: Request, response: Response): Promise<Response> {
    const {
      payment_method,
      receipt_email,
      service_id,
      product_id,
      payer,
      transaction_amount
    } = request.body;

    const client_id = request.user.id;

    try {
      const createPaymentService = container.resolve(CreatePaymentService);

      const sessionUrl = await createPaymentService.execute({
        client_id,
        payment_method,
        receipt_email,
        service_id,
        product_id,
        transaction_amount,
        payer,
      });

      return response.status(200).json({ sessionUrl });
    } catch (err) {
      if (err instanceof Stripe.errors.StripeError) {
        logger.error(err);
        throw new AppError('Não foi possível gerar uma sessão para realizar o checkout. Tente novamente mais tarde.')
      }

      throw err;
    }
  }
}

export default CreatePaymentController;
