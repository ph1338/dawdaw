import Stripe from 'stripe';
import logger from '@shared/functions/logger'
import { inject, injectable } from 'tsyringe';

import IStripeProvider from '@modules/subscriptions/providers/StripeProvider/models/IStripeProvider';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import ISubscriptionsRepository from '@modules/subscriptions/infra/typeorm/repositories/models/ISubscriptionsRepository';
import INotificationsRepository from '@modules/notifications/repositories/INotificationsRepository';
import Listener from '../types/Listener'

@injectable()
class SubscriptionDeletedEvent implements Listener {
  private stripe: Stripe;

  constructor(
    @inject('StripeProvider')
    private stripeProvider: IStripeProvider,
    
    @inject('SubscriptionsRepository')
    private subscriptionsRepository: ISubscriptionsRepository,

    @inject('NotificationsRepository')
    private notificationsRepository: INotificationsRepository,
  ) {
    this.stripe = this.stripeProvider.getStripe();
  }

  async eventListener(event: Stripe.Event): Promise<void> {
    const subscription = event.data.object as Stripe.Subscription;
    
    const databaseSubscription = await this.subscriptionsRepository.getSubscriptionBySubId(subscription.id);
    if (databaseSubscription) {
      this.subscriptionsRepository.deleteSubscription(databaseSubscription.id);
    }
  }
}

export default SubscriptionDeletedEvent;