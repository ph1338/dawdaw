import logger from '@shared/functions/logger';
import Listener from '../types/Listener';
import { container } from 'tsyringe';
import CheckoutCompletedEvent from './CheckoutCompletedEvent';
import Stripe from 'stripe';

const events: Record<string, any> = {};

export function dispatchEvent(eventName: string, event: Stripe.Event) {
  console.log(eventName);
  
  const eventListener = events[eventName];
  if (!eventListener) return;
  

  const listener: Listener = container.resolve(eventListener);
  listener.eventListener(event);
}

export function registerEvent(eventName: string, eventListener: any) {
  events[eventName] = eventListener;
}
