import Stripe from 'stripe';
import logger from '@shared/functions/logger'
import { inject, injectable } from 'tsyringe';

import IStripeProvider from '@modules/subscriptions/providers/StripeProvider/models/IStripeProvider';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import ISubscriptionsRepository from '@modules/subscriptions/infra/typeorm/repositories/models/ISubscriptionsRepository';
import INotificationsRepository from '@modules/notifications/repositories/INotificationsRepository';
import Listener from '../types/Listener'

@injectable()
class CheckoutExpireEvent implements Listener {
  private stripe: Stripe;

  constructor(
    @inject('StripeProvider')
    private stripeProvider: IStripeProvider,

    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,

    @inject('SubscriptionsRepository')
    private subscriptionsRepository: ISubscriptionsRepository,

    @inject('NotificationsRepository')
    private notificationsRepository: INotificationsRepository,
  ) {
    this.stripe = this.stripeProvider.getStripe();
  }

  async eventListener(event: Stripe.Event): Promise<void> {
    const checkout = event.data.object as Stripe.Checkout.Session;

    if (checkout.status === 'expired') {
      const payment = await this.paymentsRepository.getPaymentByCheckoutId(checkout.id);
      if (payment) this.paymentsRepository.deletePayment(payment.id);

      // Pode notificar o usuário aqui, pedindo para ele tentar fazer o pedido novamente.
    }
  }
}

export default CheckoutExpireEvent;