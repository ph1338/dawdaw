import Stripe from 'stripe';
import logger from '@shared/functions/logger'
import { inject, injectable } from 'tsyringe';

import IStripeProvider from '@modules/subscriptions/providers/StripeProvider/models/IStripeProvider';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import ISubscriptionsRepository from '@modules/subscriptions/infra/typeorm/repositories/models/ISubscriptionsRepository';
import INotificationsRepository from '@modules/notifications/repositories/INotificationsRepository';
import Listener from '../types/Listener'
import IRequestsRepository from '@modules/orders/repositories/IRequestsRepository';
import IAccountsSmurfsRepository from '@modules/accountsSmurfs/repositories/IAccountsSmurfRepository';

@injectable()
class CheckoutCompletedEvent implements Listener {
  private stripe: Stripe;

  constructor(
    @inject('StripeProvider')
    private stripeProvider: IStripeProvider,

    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,

    @inject('SubscriptionsRepository')
    private subscriptionsRepository: ISubscriptionsRepository,

    @inject('NotificationsRepository')
    private notificationsRepository: INotificationsRepository,

    @inject('RequestsRepository')
    private requestsRepository: IRequestsRepository,

    @inject('AccountsSmurfsRepository')
    private accountsSmurfsRepository: IAccountsSmurfsRepository,
  ) {
    this.stripe = this.stripeProvider.getStripe();
  }

  async eventListener(event: Stripe.Event): Promise<void> {
    
    const checkout = event.data.object as Stripe.Checkout.Session;


    if (!checkout.customer_email) {
      logger.warn(`A sessão de checkout ${checkout.id} não possui um endereço de e-mail do cliente associado a ela, impossibilitando o processamento do evento ${event.id}`);
      // Notification to Admins here.
      return;
    }

    const user = await this.usersRepository.findByEmail(checkout.customer_email);
    if (!user) {
      console.log(user)
      logger.warn(`O endereço de e-mail ${checkout.customer_email} inserido na sessão de checkout ${checkout.id} não está cadastrado em nossa base de dados, impossibilitando o processamento do evento ${event.id}`);
      // Notification to Admins here.
      return;
    }

    if (checkout.mode === 'payment') {
      const payment = await this.paymentsRepository.getPaymentByCheckoutId(checkout.id);
      if (!payment) {
        logger.warn(`A sessão de checkout ${checkout.id} associada ao usuário ${user.id} não está registrada em nossa base de dados, impossibilitando o processamento do evento ${event.id}`);
        // Notification to Admins here.
        return;
      }

      if (payment.service_id) {
        const order = await this.requestsRepository.findById(payment.service_id);
        if (!order) {
          logger.warn(`O pedido ${payment.service_id} não existe. Isso impediu o processamento do evento ${event.id}`);
          return;
        }

        order.status_payment = checkout.payment_status === 'paid' ? 'approved' : 'cancelled';
        this.requestsRepository.save(order);
      }
      if (payment.product_id) {
        const order = await this.accountsSmurfsRepository.findById(payment.product_id);
        if (!order) {
          logger.warn(`O produto ${payment.service_id} não existe. Isso impediu o processamento do evento ${event.id}`);
          return;
        }

        order.status_payment = checkout.payment_status === 'paid' ? 'approved' : 'cancelled';
        this.accountsSmurfsRepository.save(order);
      }

      payment.payment_status = checkout.payment_status;
      this.paymentsRepository.save(payment);
    }
    if (checkout.mode === 'subscription') {
      const subscription = await this.subscriptionsRepository.getSubscriptionByCheckoutId(checkout.id);
      if (!subscription) {
        logger.warn(`A sessão de checkout ${checkout.id} associada ao usuário ${user.id} não está registrada em nossa base de dados, impossibilitando o processamento do evento ${event.id}`);
        // Notification to Admins here.
        return;
      }
      if (!checkout.subscription) {
        logger.warn(`A sessão de checkout ${checkout.id} associada ao usuário ${user.id} não tem uma assinatura associada a ela, impossibilitando o processamento do evento ${event.id}`);
        // Notification to Admins here.
        return;
      }

      const subscription_id = typeof checkout.subscription === 'string' ? checkout.subscription : checkout.subscription.id;

      user.subscribed = true;
      user.subscription_id = subscription_id;
      this.usersRepository.save(user);
      
      subscription.payment_status = checkout.payment_status;
      subscription.subscription_id = subscription_id;
      this.subscriptionsRepository.save(subscription);
    }
  }
}

export default CheckoutCompletedEvent;
