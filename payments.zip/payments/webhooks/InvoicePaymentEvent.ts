import Stripe from 'stripe';
import logger from '@shared/functions/logger'
import { inject, injectable } from 'tsyringe';

import IStripeProvider from '@modules/subscriptions/providers/StripeProvider/models/IStripeProvider';
import IUsersRepository from '@modules/users/repositories/users/IUsersRepository';
import IPaymentsRepository from '../infra/typeorm/repositories/models/IPaymentsRepository';
import ISubscriptionsRepository from '@modules/subscriptions/infra/typeorm/repositories/models/ISubscriptionsRepository';
import ListAllRequestsBoosterService from '@modules/orders/services/ListAllRequestsClientService';

import Listener from '../types/Listener'
import INotificationsRepository from '@modules/notifications/repositories/INotificationsRepository';

@injectable()
class InvoicePaymentEvent implements Listener {
  private stripe: Stripe;

  constructor(
    private listAllRequestsBoosterService: ListAllRequestsBoosterService,
    
    @inject('StripeProvider')
    private stripeProvider: IStripeProvider,

    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('PaymentsRepository')
    private paymentsRepository: IPaymentsRepository,

    @inject('SubscriptionsRepository')
    private subscriptionsRepository: ISubscriptionsRepository,

    @inject('NotificationsRepository')
    private notificationsRepository: INotificationsRepository,
  ) {
    this.stripe = this.stripeProvider.getStripe();
  }

  async eventListener(event: Stripe.Event): Promise<void> {
    const invoice = event.data.object as Stripe.Invoice;
    
  //   let id = '00350c88-83f9-4396-bd00-63298c38f840'
  //   try {
  //     const requestList = await this.listAllRequestsBoosterService.execute({
  //       id,
  //       toSecure: '66dthyt6grgrtfdsfsf', 
  //     });
  //     console.log(requestList);
  //   } catch (error) {
  //  console.error(error);
  //   }

    if (!invoice.customer_email) {
      logger.warn(`A fatura ${invoice.id} não possui um endereço de e-mail do cliente associado a ela, impossibilitando o processamento do evento ${event.id}`,);
      // Notification to Admins here.
      return;
    }

    const user = await this.usersRepository.findByEmail(invoice.customer_email);
    if (!user) {
      logger.warn(`O endereço de e-mail ${invoice.customer_email} inserido na fatura ${invoice.id} não está cadastrado em nossa base de dados, impossibilitando o processamento do evento ${event.id}`);
      // Notification to Admins here.
      return;
    }

    if (invoice.paid === false) {
      user.subscribed = false;
      this.usersRepository.save(user);

      // Notificar aqui que o usuário tem faturas em aberto.

      return;
    }

    user.subscribed = true;
    this.usersRepository.save(user);
  }
}

export default InvoicePaymentEvent;