import { PaymentCreateResponse, PaymentGetResponse } from 'mercadopago/resources/payment';
import IMercadoPagoProvider from '../models/IMercadoPagoProvider';
import mercadopago from 'mercadopago';
import { ICreatePixPayment, ICreatePixPaymentRequest } from '@modules/payments/types/ICreatePixPayment'

class MercadoPagoProvider implements IMercadoPagoProvider {
  private mercadoPago;

  constructor() {
    this.mercadoPago = mercadopago;
    this.mercadoPago.configurations.setAccessToken(
      process.env.APP_ACCESS_TOKEN as string,
    );
  }

  async createPayment({
    payer,
    description,
    transaction_amount,
  }: ICreatePixPayment): Promise<PaymentCreateResponse> {
    const payment = await this.mercadoPago.payment.create({
      payer: {
        email: payer.email,
        first_name: payer.first_name,
        last_name: payer.last_name,
        identification: {
          type: 'CPF',
          number: payer.identification.number,
        },
      },
      installments: 1,
      payment_method_id: 'pix',
      description: description,
      transaction_amount: transaction_amount,
    });

    return payment;
  }

  async getPaymentById(
    payment_id: number,
  ): Promise<PaymentGetResponse> {
    const result = await this.mercadoPago.payment.get(payment_id);
    return result;
  }
}

export default MercadoPagoProvider;
