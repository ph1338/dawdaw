import { ICreatePixPayment } from '@modules/payments/types/ICreatePixPayment'
import { PaymentCreateResponse, PaymentGetResponse } from 'mercadopago/resources/payment'

export default interface IMercadoPagoProvider {
  createPayment({ payer, description, transaction_amount }: ICreatePixPayment): Promise<PaymentCreateResponse>;
  getPaymentById(payment_id: number): Promise<PaymentGetResponse>;
}
