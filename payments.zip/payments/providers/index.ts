import { container } from 'tsyringe';

import IMercadoPagoProvider from './models/IMercadoPagoProvider';
import MercadoPagoProvider from './implementations/MercadoPagoProvider';

container.registerSingleton<IMercadoPagoProvider>(
  'MercadoPagoProvider',
  MercadoPagoProvider,
);
